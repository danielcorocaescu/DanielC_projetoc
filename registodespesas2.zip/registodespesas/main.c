#include <stdio.h>
#include <stdlib.h>
#include "vv.h"
#include "locale.h"




int main() {
    setlocale(LC_ALL, "Portuguese");
    Despesa despesas[MAX_REGISTROS];
    conta contas[MAX_CONTAS];
    int numDespesas = 0;
    int numContas = 0;
    char opcao;
    bool logado = false;

    carregarDespesas(despesas, &numDespesas);

    carregarContas(contas, &numContas);

    printf("\n");

    textcolor(RED);

    printf(R"EOF(  _____            _     _              _        _____
|  __ \          (_)   | |            | |      |  __ \
| |__) |___  __ _ _ ___| |_ ___     __| | ___  | |  | | ___  ___ _ __   ___  ___  __ _ ___
|  _  // _ \/ _` | / __| __/ _ \   / _` |/ _ \ | |  | |/ _ \/ __| '_ \ / _ \/ __|/ _` / __|
| | \ \  __/ (_| | \__ \ || (_) | | (_| |  __/ | |__| |  __/\__ \ |_) |  __/\__ \ (_| \__ \
|_|  \_\___|\__, |_|___/\__\___/   \__,_|\___| |_____/ \___||___/ .__/ \___||___/\__,_|___/
             __/ |                                              | |
            |___/                                               |_|

 )EOF");

    do {
        textcolor(MAGENTA);

        printf("=== Gerenciador de Despesas ===\n");
        printf("1. Registar conta\n");
        printf("2. Salvar Conta\n");
        printf("3. Entrar na conta\n");
        opcao = getch();
        fflush(stdin);
        switch (opcao) {
            case '1':
                system("cls");
                registarconta(contas, &numContas);
                break;

            case '2':
                system("cls");
                salvarContas(contas, numContas);
                break;

            case '3':
                system("cls");
                logado = entrarConta(contas, numContas);
                if (!logado) {
                    printf("Conta n�o encontrada. Por favor, verifique o nome de usu�rio e senha.\n");
                }
                break;
        }

        if (!logado) {
            continue;  // Retorna ao menu principal
        }


        system("cls");
        printf("1. Registar despesa\n");
        printf("2. Mostrar despesas\n");
        printf("3. Guardar despesas\n");
        printf("4. Alterar despesas\n");
        printf("5. Sair\n");
        printf("Digite sua op��o: ");
        opcao = getch();
        printf("\n");

        switch (opcao) {
            case '1':
                system("cls");
                cadastrarDespesa(despesas, &numDespesas);
                break;

            case '2':
                system("cls");
                exibirDespesas(despesas, numDespesas);
                break;

            case '3':
                system("cls");
                salvarDespesas(despesas, numDespesas);
                break;

            case '4':
                system("cls");
                modificarDespesa(despesas, numDespesas);
                break;

            case '5':
                system("cls");
                textcolor(RED);
                printf("Saindo...\n");
                sleep(3);
                return 0;

            default:
                system("cls");
                printf("Op��o inv�lida.\n");
        }

        printf("\n");
    } while (opcao != '5');

    return 0;
}
