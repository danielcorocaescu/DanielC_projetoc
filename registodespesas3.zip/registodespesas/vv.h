#ifndef VV_H_INCLUDED
#define VV_H_INCLUDED

#include <conio.c>
#include <stdbool.h>
#include <conio.h>

#define MAX_DESCRICAO 50
#define MAX_CATEGORIA 20
#define MAX_REGISTROS 100

#define MAX_CONTAS 100


typedef struct {
    char nome[30];
    char senha[8];
} conta;

void inicializarContas() {
    FILE* arquivo = fopen("contas.txt", "r");
    if (arquivo == NULL) {
        arquivo = fopen("contas.txt", "w");
        if (arquivo != NULL) {
            // Escrever conta de administrador padr�o no arquivo
            fprintf(arquivo, "admin\nadmin\n");
            fclose(arquivo);
        }
    }
}

void carregarContas(conta* contas, int* numContas) {
    FILE* arquivo = fopen("contas.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo de contas.\n");
        return;
    }

    *numContas = 0;
    char linha[30];

    while (fgets(linha, sizeof(linha), arquivo)) {
        strtrim(linha);
        strcpy(contas[*numContas].nome, linha);

        fgets(linha, sizeof(linha), arquivo);
        strtrim(linha);
        strcpy(contas[*numContas].senha, linha);

        (*numContas)++;
    }

    fclose(arquivo);
}

void registarconta(conta* contas, int* numcontas) {
    if (*numcontas >= MAX_CONTAS) {
        printf("Limite de contas atingido!!!\n");
        return;
    }

    conta novaconta;

    printf("Digite o seu nome: ");
    fgets(novaconta.nome, sizeof(novaconta.nome), stdin);
    novaconta.nome[strcspn(novaconta.nome, "\n")] = '\0';

    printf("Digite a sua senha: ");
    fgets(novaconta.senha, sizeof(novaconta.senha), stdin);
    novaconta.senha[strcspn(novaconta.senha, "\n")] = '\0';

    contas[*numcontas] = novaconta;
    (*numcontas)++;

    salvarContas(contas, *numcontas);

    printf("\n");
    printf("Conta registrada com sucesso!\n");
}


void salvarContas(conta* contas, int numContas) {
    FILE* arquivo = fopen("contas.txt", "r+");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo de contas.\n");
        return;
    }

    for (int i = 0; i < numContas; i++) {
        fprintf(arquivo, "%s\n%s\n", contas[i].nome, contas[i].senha);
    }

    fclose(arquivo);
    printf("Contas salvas com sucesso!\n");
}


void strtrim(char* str) {
    // Remove espa�os em branco no in�cio da string
    int i = 0;
    while (str[i] == ' ' || str[i] == '\t') {
        i++;
    }
    if (i > 0) {
        memmove(str, str + i, strlen(str + i) + 1);
    }

    // Remove espa�os em branco no final da string
    i = strlen(str) - 1;
    while (i >= 0 && (str[i] == ' ' || str[i] == '\t' || str[i] == '\n' || str[i] == '\r')) {
        str[i] = '\0';
        i--;
    }
}

bool entrarConta(conta* contas, int numContas) {
    char nome[30];
    char senha[30];

    printf("Digite o nome da conta: ");
    fgets(nome, sizeof(nome), stdin);
    nome[strcspn(nome, "\n")] = '\0';

    printf("Digite a senha: ");
    fgets(senha, sizeof(senha), stdin);
    senha[strcspn(senha, "\n")] = '\0';

    for (int i = 0; i < numContas; i++) {
        if (strcmp(contas[i].nome, nome) == 0 && strcmp(contas[i].senha, senha) == 0) {
            return true;  // Login bem-sucedido
        }
    }

    return false;  // Login falhou
}


typedef struct {
    int numero;
    char descricao[MAX_DESCRICAO];
    char categoria[MAX_CATEGORIA];
    float valor;
} Despesa;



void cadastrarDespesa(Despesa* despesas, int* numDespesas) {
    if (*numDespesas >= MAX_REGISTROS) {
        printf("Limite de despesas atingido.\n");
        return;
    }

    Despesa novaDespesa;

    textcolor(LIGHTBLUE);

    printf("Digite a descri��o da despesa: ");
    fgets(novaDespesa.descricao, MAX_DESCRICAO, stdin);
    novaDespesa.descricao[strcspn(novaDespesa.descricao, "\n")] = '\0';

    printf("Digite a categoria da despesa: ");
    fgets(novaDespesa.categoria, MAX_CATEGORIA, stdin);
    novaDespesa.categoria[strcspn(novaDespesa.categoria, "\n")] = '\0';

    printf("Digite o valor da despesa: ");
    scanf("%f", &novaDespesa.valor);
    getchar();

    despesas[*numDespesas] = novaDespesa;
    (*numDespesas)++;

    textcolor(LIGHTGREEN);

    printf("\n");

    printf("Despesa registrada com sucesso!\n");
}

void exibirDespesas(Despesa* despesas, int numDespesas) {
    if (numDespesas == 0) {
        printf("Nenhuma despesa registrada.\n");
        return;
    }
    else{
    textcolor(GREEN);
    printf("Lista de despesas:\n");
    printf("\n");
    for (int i = 0; i < numDespesas; i++) {
       textcolor(YELLOW);
        printf("\n");
        printf("----------------------------\n");
        printf("Descri��o: %s\n", despesas[i].descricao);
        printf("Categoria: %s\n", despesas[i].categoria);
        printf("Valor: %.2f\n", despesas[i].valor);
        printf("----------------------------\n");
        printf("\n");
    }
    }
}

void salvarDespesas(Despesa* despesas, int numDespesas) {
    FILE* ficheiro = fopen("despesas.txt", "w");
    if (ficheiro == NULL) {
        printf("Erro ao abrir o ficheiro.\n");
        return;
    }

    for (int i = 0; i < numDespesas; i++) {
        fprintf(ficheiro, "%s;%s;%.2f\n", despesas[i].descricao, despesas[i].categoria, despesas[i].valor);
    }

    fclose(ficheiro);

    textcolor(LIGHTGREEN);

    printf("Despesas salvas com sucesso!\n");
}

void carregarDespesas(Despesa* despesas, int* numDespesas) {
    FILE* ficheiro = fopen("despesas.txt", "r");
    if (ficheiro == NULL) {
        printf("Erro ao abrir o ficheiro.\n");
        return;
    }

    *numDespesas = 0;
    char linha[MAX_DESCRICAO + MAX_CATEGORIA + 8];

    while (fgets(linha, sizeof(linha), ficheiro)) {
        Despesa novaDespesa;
        sscanf(linha, "%[^;];%[^;];%f", novaDespesa.descricao, novaDespesa.categoria, &novaDespesa.valor);
        despesas[*numDespesas] = novaDespesa;
        (*numDespesas)++;
    }

    fclose(ficheiro);
    printf("Despesas carregadas com sucesso!\n");
}

void modificarDespesa(Despesa* despesas, int numDespesas) {
    if (numDespesas == 0) {
        printf("Nenhuma despesa cadastrada.\n");
        return;
    }
    else
    {
    textcolor(GREEN);
    printf("Lista de despesas:\n");
    printf("\n");

    for (int i = 0; i < numDespesas; i++) {
      textcolor(YELLOW);
        printf("N�mero: %d\n", i); // N�mero de identifica��o
        printf("Descri��o: %s\n", despesas[i].descricao);
        printf("Categoria: %s\n", despesas[i].categoria);
        printf("Valor: %.2f\n", despesas[i].valor);
        printf("----------------------------\n");
    }
    }

    int indice;

    textcolor(YELLOW);
    printf("Digite o �ndice da despesa que deseja modificar (0 a %d): ", numDespesas - 1);
    scanf("%d", &indice);
    getchar();

    if (indice < 0 || indice >= numDespesas) {
        printf("�ndice inv�lido.\n");
        return;
    }

    Despesa despesaModificada;

    printf("Digite a nova descri��o da despesa: ");
    fgets(despesaModificada.descricao, MAX_DESCRICAO, stdin);
    despesaModificada.descricao[strcspn(despesaModificada.descricao, "\n")] = '\0';

    printf("Digite a nova categoria da despesa: ");
    fgets(despesaModificada.categoria, MAX_CATEGORIA, stdin);
    despesaModificada.categoria[strcspn(despesaModificada.categoria, "\n")] = '\0';

    printf("Digite o novo valor da despesa: ");
    scanf("%f", &despesaModificada.valor);
    getchar();

    despesas[indice] = despesaModificada;

    textcolor(LIGHTGREEN);
    printf("Despesa modificada com sucesso!\n");
}


#endif // VV_H_INCLUDED
