#include <stdio.h>
#include <stdlib.h>
#include "vv.h"
#include "locale.h"
#include <stdbool.h>



int main() {
    setlocale(LC_ALL, "Portuguese");
    Despesa despesas[MAX_REGISTROS];
    conta contas[MAX_CONTAS];
    int numDespesas = 0;
    int numContas = 0;
    int opcao;
    bool logado = false;

    carregarDespesas(despesas, &numDespesas);

    printf("\n");

    textcolor(RED);

    printf(R"EOF(  _____            _     _              _        _____
|  __ \          (_)   | |            | |      |  __ \
| |__) |___  __ _ _ ___| |_ ___     __| | ___  | |  | | ___  ___ _ __   ___  ___  __ _ ___
|  _  // _ \/ _` | / __| __/ _ \   / _` |/ _ \ | |  | |/ _ \/ __| '_ \ / _ \/ __|/ _` / __|
| | \ \  __/ (_| | \__ \ || (_) | | (_| |  __/ | |__| |  __/\__ \ |_) |  __/\__ \ (_| \__ \
|_|  \_\___|\__, |_|___/\__\___/   \__,_|\___| |_____/ \___||___/ .__/ \___||___/\__,_|___/
             __/ |                                              | |
            |___/                                               |_|

 )EOF");

    do {
        textcolor(MAGENTA);

        printf("=== Gerenciador de Despesas ===\n");
        printf("1. Registar conta\n");
        printf("2. Salvar Conta\n");
        printf("3. Entrar na conta\n");
        scanf("%i", &opcao);
        fflush(stdin);
        switch (opcao)
        {
            case 1:
                registarconta(contas, &numContas);
                break;
            case 2:
                salvarContas(contas, numContas);
                break;
            case 3:
                entrarConta(contas, numContas);
                logado = true;  // Atualiza a vari�vel logado para true ap�s o login
                break;
        }

        if (!logado) {
            printf("Voc� precisa estar logado para acessar as despesas.\n");
            continue;  // Retorna ao menu principal
        }


        else
        {

        system("cls");

        printf("1. Registar despesa\n");
        printf("2. Mostrar despesas\n");
        printf("3. Guardar despesas\n");
        printf("4. Limpar consola\n");
        printf("5. Alterar despesas\n");
        printf("6. Sair\n");
        printf("Digite sua op��o: ");
        scanf("%d", &opcao);
        getchar();
        printf("\n");


        switch (opcao) {
            case 1:
                cadastrarDespesa(despesas, &numDespesas);
                break;
            case 2:
                exibirDespesas(despesas, numDespesas);
                break;
            case 3:
                salvarDespesas(despesas, numDespesas);
                break;
            case 4:
                system("cls");
                break;
            case 5:
                modificarDespesa(despesas, numDespesas);
                break;
            case 6:
                textcolor(RED);
                printf("Saindo...\n");
                return 0;
                break;
            default:
                printf("Op��o inv�lida.\n");
        }

        printf("\n");
        }
    } while (opcao != 7);
}
